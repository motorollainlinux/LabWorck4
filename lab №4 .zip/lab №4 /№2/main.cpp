/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <stdio.h>
#include <math.h>

using namespace std;
int a, b, c, p, S; 
void function(int, int, int)
{
     p = (a+b+c)/2;
     S = sqrt(p*(p-a)*(p-b)*(p-c));
     cout << "площядь треугольника" << S << "\n";
}
int main()
{
     cout << "введите первую сторону\n";
     cin >> a;
     cout << "введите вторую сторону\n";
     cin >> b;
     cout << "введите третью сторону\n";
     cin >>c;
     function(a, b, c);
     return 0;
}
